let counter = 3;
var container = document.getElementById("form-lower");
const table = document.getElementById("tbody");
const form = document.getElementById("form");
const identity = document.getElementById("identity");

var data = {
    education: {}
};
function deleteRow(index) {
    var elem = document.getElementById("row" + index);
    var hr = document.getElementById(`hr${index}`);
    // console.log(elem);
    container.removeChild(elem);
    container.removeChild(hr);
}
function addRow() {
    const elem = document.getElementById("row2").cloneNode(true);

    elem.childNodes[1].childNodes[1].childNodes[4].value = ""
    elem.childNodes[3].childNodes[1].childNodes[4].value = ""
    elem.childNodes[9].childNodes[1].childNodes[4].value = ""
    elem.childNodes[11].childNodes[1].childNodes[4].value = ""

    // console.log(elem.childNodes[13].childNodes[1]);
    const nodem = document.createElement("i");
    const hr = document.createElement("hr");

    hr.setAttribute("style", "width:100%");
    hr.setAttribute("id", `hr${counter}`);

    nodem.setAttribute("class", "fa fa-minus ms-auto")
    elem.childNodes[13].childNodes[1].setAttribute("onclick", `deleteRow(${counter})`);
    elem.childNodes[13].childNodes[1].classList.add("delete-btn-active");

    elem.setAttribute("id", "row" + counter);
    // elem.appendChild(nodem);

    counter++;
    container.appendChild(hr);
    container.appendChild(elem);
    // console.log(elem);
}
function getData() {
    // console.log(document.forms);
    // var data = {
    //     education: []
    // };
    data = {
        education: {}
    };
    data.firstName = document.forms[0]["fname"].value;
    data.lastName = document.forms[0]["lname"].value;
    data.dob = document.forms[0]["dob"].value;
    data.email = document.forms[0]["email"].value;
    data.address = document.forms[0]["address"].value;
    data.graduation = document.forms[0]["gy"].value;

    const degree = document.getElementsByClassName("degree");
    const school = document.getElementsByClassName("school");
    const start = document.getElementsByClassName("startDate");
    const passout = document.getElementsByClassName("passout");
    const percentage = document.getElementsByClassName("percentage");
    const backlog = document.getElementsByClassName("backlog");
    for (let i = 0; i < degree.length; i++) {
        const obj = {};
        if (degree[i].value == "" && school[i].value == "" && start[i].value == "" && passout[i].value == "" && percentage[i].value == "" && backlog[i].value == "") {
            // console.log("object is empty");
            continue;
        }
        else {
            obj.degree = degree[i].value;
            obj.school = school[i].value;
            obj.startDate = start[i].value;
            obj.passout = passout[i].value;
            obj.percentage = percentage[i].value;
            obj.backlog = backlog[i].value;
            data.education["row" + i] = obj;
        }
    }
    console.log("Form Data", data);
    displayData(data);
    form.reset();
}
function displayData(e) {
    table.innerHTML = "";
    identity.innerHTML = "";
   
    let count = 0;
    for (let key in e) {
        if (key == "education" || e[key] == "") {
            console.log(e.key);
            continue;
        }
        else {
            const p = document.createElement("p");
            p.innerHTML = `${key} = ${e[key]}`;
            identity.appendChild(p);
        }
    }
    for (let key in e.education) {
        // console.log(key);
        const tr = document.createElement("tr");
        const td1 = document.createElement("td");
        const td2 = document.createElement("td");
        const td3 = document.createElement("td");
        const td4 = document.createElement("td");
        const td5 = document.createElement("td");
        const td6 = document.createElement("td");
        const td7 = document.createElement("td");

        td1.innerHTML = e.education[key].degree;
        td2.innerHTML = e.education[key].school;
        td3.innerHTML = e.education[key].startDate;
        td4.innerHTML = e.education[key].passout;
        td5.innerHTML = e.education[key].percentage;
        td6.innerHTML = e.education[key].backlog;

        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);
        tr.appendChild(td6);
        tr.setAttribute("id", "tableRow" + count);

        td7.innerHTML = `
        <button class="submitButton p-2  edit-btn" onclick="edit(${count})">
            Edit
        </button>
        <button class="submitButton p-2 delete-btn" onclick="deleteRowTable(${count})">
            Delete
        </button>
        `;
        count++;
        tr.appendChild(td7);
        table.appendChild(tr);
    }
    // for (let obj of e.education) {
    //     const tr = document.createElement("tr");
    //     const td1 = document.createElement("td");
    //     const td2 = document.createElement("td");
    //     const td3 = document.createElement("td");
    //     const td4 = document.createElement("td");
    //     const td5 = document.createElement("td");
    //     const td6 = document.createElement("td");
    //     const td7 = document.createElement("td");

    //     td1.innerHTML = obj.degree;
    //     td2.innerHTML = obj.school;
    //     td3.innerHTML = obj.startDate;
    //     td4.innerHTML = obj.passout;
    //     td5.innerHTML = obj.percentage;
    //     td6.innerHTML = obj.backlog;

    //     tr.appendChild(td1);
    //     tr.appendChild(td2);
    //     tr.appendChild(td3);
    //     tr.appendChild(td4);
    //     tr.appendChild(td5);
    //     tr.appendChild(td6);
    //     tr.setAttribute("id", "tableRow" + count);
    //     const temp1 = JSON.stringify(obj);
    //     console.log(temp1);
    //     td7.innerHTML = `
    //     <button class="edit-btn" onclick="edit(${count})">
    //         Edit
    //     </button>
    //     <button class="delete-btn" onclick="deleteRow(${count})">
    //         Delete
    //     </button>
    //     `;
    //     count++;
    //     tr.appendChild(td7);
    //     table.appendChild(tr);
    // }
}
function edit(row) {
    const elem = document.getElementById("tableRow" + row);
    const tds = elem.getElementsByTagName("td");

    for (let i = 0; i < tds.length; i++) {
        let dataType = "text";
        if (i == 2 || i == 3) {
            dataType = "month"
        }
        else if (i == 5) {
            dataType = "number";
        }
        else if (i == 6) {
            tds[i].innerHTML = `<button class="submitButton p-2 save-btn" onclick="save(${row})">save</button>`;
            continue;
        }
        tds[i].innerHTML = `<input type=${dataType} value="${tds[i].innerText}"></input>`;
    }
}
function save(row) {
    const elem = document.getElementById("tableRow" + row);
    const tds = elem.getElementsByTagName("td");
    const keys = ["degree", "school", "startDate", "passout", "percentage", "backlog"];
    
    let count = 0;
    const temp = {};
    for (let key of keys) {
        temp[key] = tds[count].querySelectorAll("input")[0].value;
        tds[count].innerHTML = tds[count].querySelectorAll("input")[0].value;
        count++;
    }
    tds[count].innerHTML = `
    <button class="submitButton p-2  edit-btn" onclick="edit(${row})">Edit</button>
    <button class="submitButton p-2  delete-btn" onclick="deleteRowTable(${row})">
            Delete
        </button>
    `;
    data.education["row" + row] = temp;
    console.log("Updated Form Data", data);
}
function deleteRowTable(row) {
    const tempRow = document.getElementById("tableRow" + row);
    tempRow.remove();
    delete data.education["row" + row];
    console.log("Updated Form Data", data);
}